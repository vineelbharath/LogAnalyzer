package com.fmr;

import com.fmr.dao.LogFileDAO;
import org.junit.Test;

import java.io.IOException;

import static junit.framework.TestCase.assertNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class LogFileLoaderTest {

    public LogFileLoaderTest() throws IOException {
    }

    @Test
    public void loadEntries() throws IOException {

        LogFileDAO loader  = new LogFileDAO("C:\\\\Projects\\\\LogAnalyzer\\\\logEntries.csv");
         assertNotNull(loader);


    }






    //Do File Not Found

//    @Test
//
//    public void contentNotFound() throws IOException{
//
//        LogFileDAO loader  = new LogFileDAO();
//        BufferedReader br = new BufferedReader;
//        assertNotNull(loader.loadEntries(br.readLine()));
//
//
//    }
}
