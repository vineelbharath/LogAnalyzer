package com.fmr;

import java.io.IOException;

public class LogFileReaderApp {

    public static void main(String[] args) throws IOException {
        LogAnalyzer newloader = new LogAnalyzer();
        newloader.print("logEntries.csv", 100);



    }
}
