package com.fmr;

import com.fmr.dao.LogFileDAO;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class LogAnalyzer {


    public LogAnalyzer() throws IOException {
//        LogFileDAO  newdata  = new LogFileDAO(filepath);
//        for (int i = 0; i < maxlines; i++) {
//            System.out.println("printting " + i + "   " + newdata.data.get(i));
//
//
//        }
    }

    public List print(String filepath, int maxlines) throws IOException {
        LogFileDAO newdata = new LogFileDAO(filepath);
        List<LogEntry> list=newdata.loadEntries(filepath);
        List<LogEntry> deny = list.stream().filter(Le -> Le.getDisposition().equals("deny")).collect(Collectors.toList());


//        for (int i = 0; i < maxlines; i++) {
//            System.out.println("printting " + i + "   " + newdata.data.get(i));
        System.out.println(deny);
//
//
//        }
//
        return deny;

        }


    }

